#Version: v0.1
#Date Last Updated: 12-20-2023

#%% MODULE BEGINS
module_name = 'child1'

'''
Version: v0.1
Description:
    <***>

Authors:
   Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created     :  11/18/2024
Date Last Updated:  11/20/2024
Doc:
    <***>

Notes:
    <***>
'''

#%% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#other imports
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

#custom imports
from lib.parent1 import parent1

#%% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Class definitions Start Here
class child1(parent1):
    def __init__(self, config):
        super().__init__(config)

    def read_csv(self):
        csv_file_path = 'C:\Users\madid\Downloads\CS340_F_24_Uncommon Denominators\Root\Input\test.csv'
        csv_file_path = self.config.get('CSV_FILE_PATH')
        try:
            data = pd.read_csv(csv_file_path)
            self.log_progress(f"Data loaded from {csv_file_path}")
            return data
        except Exception as e:
            self.log_error(f"Error loading data: {e}")
            raise

    def visualize_data(self, data):
        plot_type = self.config.get('VISUALIZE_PLOT_TYPE', 'histogram')
        
        if plot_type == 'violin':
            self._plot_violin(data)
        elif plot_type == 'box':
            self._plot_box(data)
        elif plot_type == 'scatter':
            self._plot_scatter(data)
        else:
            super().visualize_data(data)

    def _plot_violin(self, data):
        sns.violinplot(data=data)
        plt.show()

    def _plot_box(self, data):
        sns.boxplot(data=data)
        plt.show()

    def _plot_scatter(self, data):
        numeric_columns = data.select_dtypes(include=['number']).columns
        if len(numeric_columns) >= 2:
            sns.scatterplot(data=data, x=numeric_columns[0], y=numeric_columns[1])
            plt.show()
        else:
            print("Not enough numeric columns for scatter plot.")

    def query_data(self, data):
        query_conditions = self.config.get('QUERY_CONDITIONS', {})
        
        '''Apply both string and numeric conditions with Boolean indexing'''
        for column, value in query_conditions.items():
            if isinstance(value, str):
                data = data[data[column].str.contains(value, na=False)]
            else:
                data = data[data[column] == value]

        return data

#%% MAIN CODE                  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main code start here

'''# Placeholder for the main execution block, where you would initiate class instances and invoke methods
# Example:
# config = {...}  # Config dictionary
# child_class_instance = ChildClass(config)
# data = child_class_instance.read_csv()
# child_class_instance.visualize_data(data) '''

#%% SELF-RUN                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main Self-run block
if __name__ == "__main__":
    # Example of self-run functionality if this script is executed directly
    config = {...}  # Provide necessary config values
    child1_class_instance = child1Class(config)
    data = child1_class_instance.read_csv()
    child1_class_instance.visualize_data(data)