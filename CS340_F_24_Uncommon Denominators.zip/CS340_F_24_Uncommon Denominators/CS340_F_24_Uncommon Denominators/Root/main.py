#Version: v0.1
#Date Last Updated: 12-20-2023

#%% MODULE BEGINS
module_name = 'main'

'''
Version: v0.1

Description:
    This file contains the main class, parent and child class set 1, parent and child class set 2.The Parent Class will handle the common functionalitties. The Child class will
inherit the Parent class and extend these functionalities as they are needed.

Authors: Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created     :  11/15/2024
Date Last Updated:  11/20/2024

Doc: <***>

Notes: <***>
'''

#%% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#custom imports
from lib.parent1_class import parent1Class
from lib.child1_class import child1Class

#other imports
import pandas as pd
import pickle
import matplotlib.pyplot as plt

#%% CONFIGURATION               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
from config import config

#%% INITIALIZATIONS             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
child1 = Child1Class(config)

#%% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Function definitions Start Here
def main():
    
    data = child1.read_csv()

    '''Visualize data'''
    child1.visualize_data(data)

    
    '''Query data'''
    queried_data = child1.query_data(data)
    print(queried_data)

    '''Export data'''
    child1.export_data(data)

#%% MAIN CODE                  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main code start here
if __name__ == '__main__':
    main()

#%% SELF-RUN                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main Self-run block
if __name__ == "__main__":
    main()