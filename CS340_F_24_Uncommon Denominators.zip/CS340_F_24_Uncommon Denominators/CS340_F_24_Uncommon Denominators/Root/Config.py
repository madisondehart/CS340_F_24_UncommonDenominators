#Version: v0.1
#Date Last Updated: 12-20-2023

#%% MODULE BEGINS
module_name = 'module'

'''
Version: v0.1

Description:
    Config Module stores configuration and constants settings which will include dictonary- based configurations for paths, plot settings, etc.

Authors:
    Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created     :  11/15/2024
Date Last Updated:  11/20/2024

Doc:
    <***>

Notes:
    <***>
'''

#%% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == "__main__":
   import os
   #os.chdir("./../..")
#

#custom imports


#other imports

'''
from   matplotlib import pyplot as plt
import mne
import numpy  as np 
import os
import pandas as pd
import seaborn as sns
'''
#%% USER INTERFACE              ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#%% CONSTANTS                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
CONFIG = {
    'input_directory': './Input/',  # Directory for input files (CSV, Pickle)
    'output_directory': './Output/',  # Directory for output files (CSV, Pickle, Images)
    'log_file': './Output/progress_log.txt',  # Log file for progress and errors
    'visualization_type': 'histogram',  # Type of visualization to use ('histogram', 'line', etc.)
    'query_condition': {'column_name': 'value'},  # Query condition for filtering data
    'export_csv': True,  # Whether to export results as CSV
    'export_pickle': True,  # Whether to export results as Pickle
    'export_image': True,  # Whether to export visualizations as image files
}

#%% CONFIGURATION               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



#%% INITIALIZATIONS             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#%% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Global declarations Start Here



#Class definitions Start Here



#Function definitions Start Here

#

#%% MAIN CODE                  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main code start here



#%% SELF-RUN                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Main Self-run block