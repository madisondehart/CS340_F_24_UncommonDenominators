# Version: v0.1
# Date Last Updated: 12-20-2023

# %% MODULE BEGINS
module_name = 'main'

# %% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
from lib.parent1 import parent1Class  # Corrected import for parent1.py
from lib.child1 import child1Class    # Corrected import for child1.py

import pandas as pd
import pickle
import matplotlib.pyplot as plt
import os
from Config import CONFIG  # Corrected to match your config variable

# %% INITIALIZATIONS             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Initialize the child class with the config object
child1 = child1Class(CONFIG)  # Pass the correct config variable

# %% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    # Ensure Input and Output directories exist
    if not os.path.exists(CONFIG['input_directory']):
        os.makedirs(CONFIG['input_directory'])  # Create Input directory if not exists
        print(f"Created input directory: {CONFIG['input_directory']}")
        
    if not os.path.exists(CONFIG['output_directory']):
        os.makedirs(CONFIG['output_directory'])  # Create Output directory if not exists
        print(f"Created output directory: {CONFIG['output_directory']}")

    # Step 1: Load the data from the Input folder
    input_file = os.path.join(CONFIG['input_directory'], 'example_data -Sheet1.csv')
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' does not exist.")
        return

    data = child1.read_csv(input_file)

    if data is None:
        print("Error: Data could not be loaded.")
        return  # Exit if there was an error loading the data

    # Step 2: Visualize the data
    child1.visualize_data(data)

    # Step 3: Query the data
    queried_data = child1.query_data(data)
    print(queried_data)

    # Step 4: Export the data to the Output folder as CSV
    output_csv_file = os.path.join(CONFIG['output_directory'], 'output_data.csv')
    child1.export_data(queried_data, output_csv_file)  # Pass queried_data instead of original data

    # Step 5: Export Visualization as PNG
    output_image_file = os.path.join(CONFIG['output_directory'], 'visualization.png')
    child1.save_visualization_as_png(output_image_file)

# %% MAIN CODE                  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == '__main__':
    main()
