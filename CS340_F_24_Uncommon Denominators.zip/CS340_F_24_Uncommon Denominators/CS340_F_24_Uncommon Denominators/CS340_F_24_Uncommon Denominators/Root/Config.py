# Version: v0.1
# Date Last Updated: 12-20-2023

'''
Version: v0.1

Description:
    Config Module stores configuration and constants settings including dictionary-based configurations
    for paths, plot settings, and other constants.

Authors:
    Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created:  11/15/2024
Date Last Updated:  11/20/2024
'''

import os

# Define the base directory for managing paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Global configuration dictionary
CONFIG = {
    # Input/Output directories
    'input_directory': os.path.join(BASE_DIR, 'Input'),  # Directory for input files (CSV, Pickle)
    'output_directory': os.path.join(BASE_DIR, 'Output'),  # Directory for output files (CSV, Pickle, Images)
    
    # Log file path for progress and errors
    'log_file': os.path.join(BASE_DIR, 'Output', 'progress_log.txt'),  
    
    # Visualization settings
    'visualization_type': 'histogram',  # Type of visualization to use ('histogram', 'line', 'scatter', etc.)
    'visualization_columns': ['col1', 'col2'],  # Columns to visualize if applicable
    
    # Query settings for filtering data
    'query_conditions': {  # Example query conditions
        'column_name': 'value',  # Replace with actual column names and values
    },
    
    # Export options
    'export_csv': True,  # Whether to export results as CSV
    'export_pickle': True,  # Whether to export results as Pickle
    'export_image': True,  # Whether to export visualizations as image files
    
    # Other configurations
    'CSV_FILE_PATH': os.path.join(BASE_DIR, 'Input', 'example_data.csv')  # Example path to the input CSV file
}
