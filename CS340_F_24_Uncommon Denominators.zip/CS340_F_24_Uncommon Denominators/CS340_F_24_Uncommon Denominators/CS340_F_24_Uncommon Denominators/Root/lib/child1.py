# Version: v0.1
# Date Last Updated: 12-20-2023

# %% MODULE BEGINS
module_name = 'child1'

'''
Version: v0.1
Description:
    This module defines the child1Class that handles reading data from a CSV file,
    visualizing the data with various plot types, and querying the data based on
    configuration settings.

Authors:
   Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created     :  11/18/2024
Date Last Updated:  11/20/2024
Doc:
    This module is designed to work with the parent class and perform data
    processing and visualization tasks.

Notes:
    The module reads CSV files, applies visualizations, and can filter data based on
    conditions specified in the config dictionary.
'''

# %% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import sys
import os

# Add the root directory to the path so Python can find 'lib'
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib')))
from parent1 import parent1Class  # Correct import for parent1.py


# %% DECLARATIONS                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class child1Class(parent1Class):
    def __init__(self, config):
        super().__init__(config)  # Initialize parent class with configuration

    def read_csv(self):
        # Use the CSV file path from the config
        csv_file_path = self.config.get('CSV_FILE_PATH', 'Input/test.csv')  # Default path if not in config
        try:
            # Read CSV file into a pandas DataFrame
            data = pd.read_csv(csv_file_path)
            self.log_progress(f"Data loaded from {csv_file_path}")
            return data
        except Exception as e:
            self.log_error(f"Error loading data: {e}")
            raise

    def visualize_data(self, data):
        plot_type = self.config.get('VISUALIZE_PLOT_TYPE', 'histogram')  # Default to histogram

        # Visualization logic based on the configuration plot type
        if plot_type == 'violin':
            self._plot_violin(data)
        elif plot_type == 'box':
            self._plot_box(data)
        elif plot_type == 'scatter':
            self._plot_scatter(data)
        else:
            super().visualize_data(data)  # Call parent method for default visualization

    def _plot_violin(self, data):
        sns.violinplot(data=data)
        plt.show()

    def _plot_box(self, data):
        sns.boxplot(data=data)
        plt.show()

    def _plot_scatter(self, data):
        numeric_columns = data.select_dtypes(include=['number']).columns
        if len(numeric_columns) >= 2:
            sns.scatterplot(data=data, x=numeric_columns[0], y=numeric_columns[1])
            plt.show()
        else:
            print("Not enough numeric columns for scatter plot.")

    def query_data(self, data):
        query_conditions = self.config.get('QUERY_CONDITIONS', {})  # Get query conditions from config

        # Apply both string and numeric conditions with Boolean indexing
        for column, value in query_conditions.items():
            if isinstance(value, str):
                data = data[data[column].str.contains(value, na=False)]
            else:
                data = data[data[column] == value]

        return data

    def export_data(self, data, output_file_path):
        try:
            data.to_csv(output_file_path, index=False)  # Export to CSV
            self.log_progress(f"Data exported to {output_file_path}")
        except Exception as e:
            self.log_error(f"Error exporting data: {e}")
            raise
