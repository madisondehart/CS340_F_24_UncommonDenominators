# Version: v0.1
# Date Last Updated: 12-20-2023

# %% MODULE BEGINS
module_name = 'parent1'

'''
Version: v0.1

Description:
    <***>

Authors:
    Madison DeHart, Natalie Tallant, Shakurah Watson

Date Created     :  11/18/2024
Date Last Updated:  11/20/2024

Doc:
    <***>

Notes:
    <***>
'''

# %% IMPORTS                    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# other imports
import pandas as pd
import matplotlib.pyplot as plt
import logging
import pickle

# %% CONFIGURATION               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
config = {
    'VISUALIZE_PLOT_TYPE': 'histogram',
    'QUERY_CONDITIONS': {},
    'LOG_FILE_PATH': 'log.txt',
    'OUTPUT_PATH': '/output/'
}

# %% CLASS DEFINITIONS           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class parent1Class:
    def __init__(self, config):
        self.config = config

    def visualize_data(self, data):
        plot_type = self.config.get('VISUALIZE_PLOT_TYPE', 'histogram')

        '''Visualize based on the selected plot type'''
        if plot_type == 'histogram':
            self._plot_histogram(data)
        elif plot_type == 'line':
            self._plot_line(data)
        else:
            print("Unsupported plot type")

    def _plot_histogram(self, data):
        data.hist(figsize=(10, 8))
        plt.show()

    def _plot_line(self, data):
        data.plot(kind='line', figsize=(10, 8))
        plt.show()

    def query_data(self, data):
        query_conditions = self.config.get('QUERY_CONDITIONS', {})
        result = data

        '''Apply simple condition-based queries'''
        for column, value in query_conditions.items():
            result = result[result[column] == value]
        return result

    def log_progress(self, message):
        logging.basicConfig(filename=self.config.get('LOG_FILE_PATH', 'log.txt'),
                            level=logging.INFO, format='%(asctime)s - %(message)s')
        logging.info(message)

    def log_error(self, error_message):
        logging.basicConfig(filename=self.config.get('LOG_FILE_PATH', 'error_log.txt'),
                            level=logging.ERROR, format='%(asctime)s - %(message)s')
        logging.error(error_message)

    def export_data(self, data):
        output_path = self.config.get('OUTPUT_PATH', '/output/')
        '''Export data to CSV and Pickle format'''
        data.to_csv(f"{output_path}/data_export.csv", index=False)
        with open(f"{output_path}/data_export.pkl", 'wb') as f:
            pickle.dump(data, f)
        self.log_progress("Data exported successfully.")

# %% INITIALIZATIONS             ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Now initialize the parent1 instance after the class definition
parent1 = parent1Class(config)

# %% MAIN CODE                  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Main code starts here
'''Assume you have some data to visualize or query.'''
data = pd.DataFrame({
    'A': [1, 2, 3, 4, 5],
    'B': [5, 4, 3, 2, 1]
})

'''Visualize data based on configuration'''
parent1.visualize_data(data)

'''Query data'''
filtered_data = parent1.query_data(data)
print(filtered_data)

'''Export data'''
parent1.export_data(data)

'''Log progress'''
parent1.log_progress("This is a progress message.")

# %% SELF-RUN                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Main Self-run block
if __name__ == "__main__":

    print(f"\"{module_name}\" module begins.")

    # TEST Code
    parent1()
